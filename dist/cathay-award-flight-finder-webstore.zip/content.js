//============================================================
// Main Userscript
//============================================================

(function() {
    'use strict';

const debug = false;
const EXTENSION_VERSION = "2026.07.15";
const unsafeWindow = window;
const GM_info = { script: { version: EXTENSION_VERSION } };
function GM_log(data) { console.log("[Cathay Award Finder]", data); }
function GM_getValue(name, defaultValue) {
    try {
        const raw = localStorage.getItem("cx_award_finder_" + name);
        return raw === null ? defaultValue : JSON.parse(raw);
    } catch (error) {
        console.warn("[Cathay Award Finder] Failed to read setting", name, error);
        return defaultValue;
    }
}
function GM_setValue(name, value) {
    try { localStorage.setItem("cx_award_finder_" + name, JSON.stringify(value)); }
    catch (error) { console.warn("[Cathay Award Finder] Failed to save setting", name, error); }
}
function GM_xmlhttpRequest(request) {
    if (!request.method || !request.url) return;
    const http = new XMLHttpRequest();
    http.withCredentials = request.withCredentials !== false;
    http.open(request.method, request.url, true);
    if (request.headers) {
        for (const key in request.headers) http.setRequestHeader(key, request.headers[key]);
    }
    if (request.onreadystatechange) http.onreadystatechange = function(){ request.onreadystatechange(this); };
    if (request.onload) http.onload = function(){ request.onload(this); };
    http.send(request.data || null);
}

if(window.location.href.indexOf("planner") > -1) {
    unsafeWindow.checkVersion = function(){
        return GM_info.script.version;
    }
}


//============================================================
// Greasymonkey Function Wrappers
//============================================================

function log(data){ if (debug) GM_log(data); }
function value_get(valueName, defaultValue) { return GM_getValue(valueName, defaultValue) }
function value_set(valueName, setValue) { GM_setValue(valueName, setValue); return setValue; }

function httpRequest(request, native = false){
    if(!native && !debug) {
        GM_xmlhttpRequest(request);
    } else {
      if (!request.method || !request.url) return;
      var http = new XMLHttpRequest();
      http.withCredentials = true;
      http.open(request.method, request.url, true);
      if (request.headers) { for ( var key in request.headers ) { http.setRequestHeader(key,request.headers[key]) } }
      if (request.onreadystatechange) http.onreadystatechange = function(){ request.onreadystatechange(this) }
      if (request.onload) http.onload = function(){ request.onload(this) }
      if (request.data) { http.send(request.data) } else { http.send() }
    }
}

//============================================================
// Initialize Variables
//============================================================

    let route_changed = false;
    let static_path = value_get("static_path", "/CathayPacificAwardV3/AML_IT3.1.14/");
    let requestVars = {};
    let tab_id = "";
    let availability_url = "https://book.cathaypacific.com/CathayPacificAwardV3/dyn/air/booking/availability?TAB_ID=";
    let form_submit_url = availability_url + tab_id;
    let autoScroll = true;

    function initCXvars(){
        if(typeof staticFilesPath !== "undefined" && static_path != staticFilesPath){
            log(typeof staticFilesPath);
            static_path = staticFilesPath;
            value_set("static_path", static_path);
        }

        if (typeof tabId === 'string') { tab_id = tabId; }
        if (typeof requestParams === 'string') {
            requestVars = JSON.parse(requestParams);
            tab_id = requestVars.TAB_ID;
        } else if (typeof requestParams === 'object') {
            requestVars = requestParams;
            tab_id = requestParams.TAB_ID || "";
        }

        form_submit_url = (typeof formSubmitUrl !== 'undefined') ? formSubmitUrl : availability_url + tab_id;
    }

    const browser_locale = navigator.language;
    const browser_lang = (browser_locale.trim().split(/-|_/)[0] == "zh") ? "zh" : "en";
    const browser_country = (browser_locale.trim().split(/-|_/)[1]?.toUpperCase() == "TW") ? "TW" : "HK";

    let login_url = "https://www.cathaypacific.com/cx/" + browser_lang + "_" +browser_country + "/sign-in.html?loginreferrer=" + encodeURI("https://www.cathaypacific.com/cx/" + browser_lang + "_" +browser_country + "/book-a-trip/redeem-flights/redeem-flight-awards.html");

//============================================================
// Helper Functions
//============================================================

    function waitForElm(selector) {return new Promise(resolve => {if (document.querySelector(selector)) {return resolve(document.querySelector(selector)); } const observer = new MutationObserver(mutations => {if (document.querySelector(selector)) {resolve(document.querySelector(selector)); observer.disconnect(); } }); observer.observe(document.body, {childList: true, subtree: true }); }); }
    function isValidDate(dateString) {if (!/^\d{8}$/.test(dateString)) return false; let year = dateString.substring(0, 4); let month = dateString.substring(4, 6); let day = dateString.substring(6, 8); if(year < 1000 || year > 3000 || month == 0 || month > 12) return false; let monthLength = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ]; if(year % 400 == 0 || (year % 100 != 0 && year % 4 == 0)) monthLength[1] = 29; if(day <= 0 || day > monthLength[month - 1]) return false; let today = new Date(); let date = new Date(year, month - 1, day); if ((date - today)/24/60/60/1000 >= 366 || (date - today)/24/60/60/1000 < -1) return false; return true; };
    function dateAdd(days = 0, date = false) { let new_date = new Date(); if(date) { let year = +date.substring(0, 4); let month = +date.substring(4, 6); let day = +date.substring(6, 8); new_date = new Date(year, month - 1, day); }; new_date.setDate(new_date.getDate() + days); return new_date.getFullYear() +""+ (new_date.getMonth() +1).toString().padStart(2, '0') +""+ new_date.getDate().toString().padStart(2, '0'); };
    function toDashedDate(date){ return date.substring(0, 4).toString() + "-" + date.substring(4, 6).toString().padStart(2, '0') + "-" + date.substring(6, 8).toString().padStart(2, '0');}
    function normaliseDate(value) { return value.replace(/-/g, ""); }
    function toDateInputValue(value) { return toDashedDate(normaliseDate(value)); }
    function toDashedDateShort(date){ return date.substring(2, 4).toString() + "-" + date.substring(4, 6).toString().padStart(2, '0') + "-" + date.substring(6, 8).toString().padStart(2, '0');}
    function dateWeekday(date){ let newdate = new Date(+date.substring(0, 4),(+date.substring(4, 6)-1),+date.substring(6, 8)); const weekday = {1:"Mon", 2:"Tue", 3:"Wed", 4:"Thu", 5:"Fri", 6:"Sat", 0:"Sun"}; return weekday[newdate.getDay()]; };
    function getFlightTime(timestamp, timeonly = false){
        let date = new Date(timestamp);
        if (timeonly) {
            let hours = (date.getUTCDate() - 1)*24 + date.getUTCHours();
            return (hours > 0 ? hours.toString() + "hr " : "") + date.getUTCMinutes().toString() + "mins";
        } else {
            return date.getUTCFullYear() + "-" + (date.getUTCMonth() + 1).toString().padStart(2, '0') + "-" + date.getUTCDate().toString().padStart(2, '0') + " " + date.getUTCHours().toString().padStart(2, '0') + ":" + date.getUTCMinutes().toString().padStart(2, '0');
        };
    };
    const airportCoords = {
        HKG:[22.308,113.918], TPE:[25.077,121.233], TSA:[25.069,121.552], KHH:[22.577,120.350],
        NRT:[35.772,140.392], HND:[35.549,139.780], KIX:[34.434,135.244], NGO:[34.858,136.805],
        ICN:[37.460,126.440], GMP:[37.558,126.791], BKK:[13.690,100.750], SIN:[1.364,103.991],
        KUL:[2.745,101.710], PEN:[5.297,100.277], MNL:[14.509,121.019], CEB:[10.307,123.979],
        SGN:[10.819,106.652], HAN:[21.221,105.807], DAD:[16.044,108.199], CGK:[-6.125,106.656],
        DPS:[-8.748,115.167], DEL:[28.556,77.100], BOM:[19.090,72.865], DXB:[25.253,55.365],
        DOH:[25.274,51.608], TLV:[32.011,34.887], LHR:[51.470,-0.454], LGW:[51.153,-0.182],
        CDG:[49.009,2.548], AMS:[52.310,4.768], FRA:[50.037,8.562], ZRH:[47.458,8.555],
        MXP:[45.630,8.723], FCO:[41.800,12.238], MAD:[40.472,-3.561], BCN:[41.297,2.078],
        MAN:[53.365,-2.272], HEL:[60.317,24.963], JFK:[40.641,-73.778], EWR:[40.689,-74.174],
        BOS:[42.365,-71.009], ORD:[41.974,-87.907], IAD:[38.953,-77.457], YYZ:[43.677,-79.624],
        YVR:[49.196,-123.181], SFO:[37.619,-122.375], LAX:[33.942,-118.408], SEA:[47.450,-122.309],
        SYD:[-33.939,151.175], MEL:[-37.669,144.841], BNE:[-27.384,153.117], PER:[-31.940,115.967],
        AKL:[-37.008,174.792], JNB:[-26.134,28.242]
    };
    function distanceMiles(from, to) {
        if (!airportCoords[from] || !airportCoords[to]) return 0;
        const rad = Math.PI / 180;
        const [lat1, lon1] = airportCoords[from];
        const [lat2, lon2] = airportCoords[to];
        const dLat = (lat2 - lat1) * rad;
        const dLon = (lon2 - lon1) * rad;
        const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLon / 2) ** 2;
        return 3958.8 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }
    function estimateCxPoints(segments, availability) {
        if (!segments.every(segment => segment.flightIdentifier.marketingAirline == "CX")) return lang.partner_points_confirm;
        const miles = segments.reduce((total, segment) => total + distanceMiles(segment.originLocation.slice(-3), segment.destinationLocation.slice(-3)), 0);
        if (!miles) return lang.points_confirm;
        const chart = [
            { max: 750, values: { y: 7500, p: 11000, j: 16000, f: 25000 } },
            { max: 2750, values: { y: 10000, p: 18000, j: 28000, f: 43000 } },
            { max: 5000, values: { y: 22000, p: 30000, j: 58000, f: 90000 } },
            { max: 7500, values: { y: 30000, p: 45000, j: 84000, f: 125000 } },
            { max: Infinity, values: { y: 38000, p: 60000, j: 110000, f: 160000 } }
        ];
        const values = chart.find(zone => miles <= zone.max).values;
        const parts = [];
        if (availability.y) parts.push(`Y ${values.y.toLocaleString()}`);
        if (availability.p) parts.push(`PY ${values.p.toLocaleString()}`);
        if (availability.j) parts.push(`J ${values.j.toLocaleString()}`);
        if (availability.f) parts.push(`F ${values.f.toLocaleString()}`);
        return parts.length ? `${lang.cx_points_estimate}: ${parts.join(" / ")}` : lang.points_confirm;
    }
    function addCss(cssString, target = shadowRoot) {
        var styleSheet = document.createElement("style");
        styleSheet.innerHTML = cssString;
        target.appendChild(styleSheet);
    }

//============================================================
// Get Stored Values
//============================================================

    let uef_from = value_get("uef_from", "HKG");
    let uef_to = value_get("uef_to", "SYD");
    let uef_date = value_get("uef_date", dateAdd(14));
    let uef_adult = value_get("uef_adult", "1");
    let uef_child = value_get("uef_child", "0");

    let ui_lang = value_get("ui_lang", browser_lang);

    let cont_query = value_get("cont_query", "0") == "0" ? 0 : 1;
    let cont_batch = value_get("cont_batch", "0") == "0" ? 0 : 1;
    let cont_ts = value_get("cont_ts", "0");
    let redirect_search = value_get("redirect_search", "0");
    let cxplanner_flights = value_get("cxplanner_flights", []) == [] ? 0 : value_get("cxplanner_flights", []);

    function reset_cont_vars() {
        if(redirect_search != "0"){
            value_set("redirect_search", "0")
        } else {
            value_set("cont_query", "0");
            value_set("cont_batch", "0");
            value_set("cont_ts", "0");
        }
    }

//============================================================
// Initialize Shadow Root
//============================================================

    const shadowWrapper = document.createElement("div");
    shadowWrapper.style.margin = 0;
    shadowWrapper.style.padding = 0;
    const shadowRoot = shadowWrapper.attachShadow({ mode: "closed" });
    const shadowContainer = document.createElement("div");

    shadowRoot.appendChild(shadowContainer);

    if (debug && unsafeWindow.shadowRoot == undefined) {
        unsafeWindow.shadowRoot = shadowRoot;
    }

    function initRoot() {
        log("initRoot();")
        addCss(styleCss);

        const current_url = new URL(window.location.href);
        const current_path = current_url.pathname;
        const ishomepage = /^\/cx\/[a-zA-Z]{2}_[a-zA-Z]{2}\.html$/;

        if(current_path.indexOf("/redibe/IBEFacade") > -1){
            log("initRoot /redibe/IBEFacade")
            waitForElm('h1').then((elm) => {
                if(elm.innerText == "Access Denied") {
                    document.body.querySelector("body > p").innerHTML = `<a href="https://www.cathaypacific.com/cx/${lang.el}_${lang.ec}/book-a-trip/redeem-flights/redeem-flight-awards.html">Go back and try again.</a>`
                }
            });
        } else if(current_path.indexOf("redeem-flight-awards.html") > -1){
            reset_cont_vars();
            log("initRoot redeem-flight-awards.html")
            waitForElm('.cmp-pageTitle__desc').then((elm) => {
                elm.before(shadowWrapper);
                initSearchBox();
                if(redirect_search != "0") {
                    btn_search.innerHTML = lang.searching;
                    btn_search.classList.add("searching");
                    setTimeout(function(){
                        location.href = redirect_search;
                    },1500);
                } else {
                    checkLogin();
                }
            });
        } else if(ishomepage.test(current_path)){
            reset_cont_vars();
            log("initRoot homepage")
            waitForElm('.bookTripPanel').then((elm) => {
                elm.insertAdjacentHTML('afterend', `
                <div class="c-grid container c-aem-text -default"><div class="row"><h2>${(browser_lang == "en" ? "Award Search Plugin" : "查票神器")}</h2><div class="ue_box"></div></div></div>`);
                document.querySelector(".ue_box").append(shadowWrapper);
                initSearchBox();
                if(redirect_search != "0") {
                    btn_search.innerHTML = lang.searching;
                    btn_search.classList.add("searching");
                    setTimeout(function(){
                        location.href = redirect_search;
                    },1500);
                } else {
                    checkLogin();
                }
            });
        } else if(current_path.indexOf("facade.html") > -1){
            reset_cont_vars();
            log("initRoot facade.html")
            waitForElm('.ibered__search-panel').then((elm) => {
                elm.before(shadowWrapper);
                initSearchBox();
                checkLogin();
            });
        } else if(current_path.indexOf("air/booking/availability") > -1 && cont_query){
            log("initRoot air/booking/availability with cont_query")
            waitForElm('body > header').then((elm) => {
                const boxes = document.querySelectorAll("body > div");
                boxes.forEach( box => { box.remove() });
                addCss(`
                html, body {overflow-x:inherit !important;}
                header {overflow-x:hidden;}
                `, document.body);
                document.body.append(shadowWrapper);
                shadowContainer.classList.add("results_container");
                if(cxplanner_flights) initCXplannerBox();
                initSearchBox();
                checkLogin();
            });
        } else if(window.location.href.indexOf("air/booking/availability") > -1){
            reset_cont_vars();
            log("initRoot air/booking/availability without cont_query")
            waitForElm('#section-flights .bound-route, #section-flights-departure .bound-route').then((elm) => {
                shadowWrapper.style.margin = "30px 20px 0px 20px";
                shadowWrapper.style.padding = 0;
                document.querySelector("#section-flights, #section-flights-departure").before(shadowWrapper);
                initSearchBox();
                checkLogin();
            });
        } else if(window.location.href.indexOf("air/booking/complexAvailability") > -1){
            reset_cont_vars();
            log("initRoot air/booking/complexAvailability")
            waitForElm('.mc-trips .bound-route').then((elm) => {
                shadowWrapper.style.margin = "30px 20px 0px 20px";
                shadowWrapper.style.padding = 0;
                document.querySelector(".mc-trips").before(shadowWrapper);
                initSearchBox();
                checkLogin();
            });
        }
    }

//============================================================
// Localisation & Search Box UI Template (Unchanged)
//============================================================

    var lang = (ui_lang != "zh") ? {
        "ec" : "HK", "el": "en", "search" : "Search", "coffee" : "If you have any questions, feel free to contact me. <span style='font-size:16px; font-weight:bold;'> (yex633967@gmail.com)</span><br>Also, welcome to join our mileage awards community! ",
        "searching" : "<img src='https://book.cathaypacific.com"+static_path+"common/skin/img/icons/cx/icon-loading.gif'> Searching...",
        "searching_w_cancel" : "<img src='https://book.cathaypacific.com"+static_path+"common/skin/img/icons/cx/icon-loading.gif'> Searching... (Click to Stop)",
        "next_batch" : "Load More...", "search_20" : "Batch Availability for 20 Days", "search_all_cabins" : "Search Availability in All Cabins",
        "flights" : "Available Flights", "nonstop":"Non-Stop", "first" : "First", "business" : "Bus", "premium" : "Prem", "economy" : "Econ",
        "first_full" : "First Class", "business_full" : "Business Class", "premium_full" : "Premium Economy", "economy_full" : "Economy Class",
        "date" : "Date", "no_flights" : "No Redemption Availability", "expired" : "Search Next 20 (Requires Refresh)",
        "searching_cont" : "<img src='https://book.cathaypacific.com"+static_path+"common/skin/img/icons/cx/icon-loading.gif'> Please wait... (Page will refresh)",
        "super" : "SuperCharged Award Search", "error" : "Unknown Error... Try Again", "bulk_batch" : "Batch Search", "bulk_flights" : "Flights",
        "new_version" : "New Version Available:", "login" : "Reminder: Login before searching.", "tab_retrieve_fail" : "Failed to retrieve key. Try logging out and in again.",
        "key_exhausted" : "Key request quota exhausted, attempting to get new key...", "getting_key" : "Attempting to retrieve API key...",
        "invalid_code": "Invalid Destination Code", "invalid_date": "Invalid Date",
        "maxsegments":"Max 6 Sectors Accepted", "multi_book":"Book Multi-City Award", "query":"Search", "delete":"Remove",
        "book_multi":"Book Multicity Award",
        "advanced":"Advanced<br>Features", "loading":"Searching...", "hu_prompt":"Looks like you're searching a lot. You might want to read this.",
        "prem_title":"Advanced Search", "prem_intro":"Search multiple dates and routes from Cathay Pacific booking pages.",
        "prem_feat1":"Search multiple routes at once.", "prem_text1":"Flexible with your routings.",
        "prem_feat2":"Review route availability.", "prem_text2":"Compare available flights.",
        "prem_feat3":"Batch search multiple routes.", "prem_text3":"Run repeated searches with one click.",
        "prem_feat4":"Submit oneworld Multi-City Award Search", "prem_text4":"Open selected routes in Cathay Pacific booking.",
        "prem_feat5":"More improvements planned.", "prem_donate":"Advanced search tools are available.",
        "human":"Cathay's website needs you to prove you're a human:", "bot_check":"Please Complete Cathay Bot Check",
        "mixed":"Mixed Class Available via", "advanced_only_alpha":"Advanced search is active.",
        "lang_toggle":"中文", "points_confirm":"Points: confirm on booking page", "partner_points_confirm":"Partner airline: confirm points on booking page", "cx_points_estimate":"Estimated points"
    } : {
        "ec" : "TW", "el": "zh", "search" : "搜索", "coffee" : "如遇任何问题，请随时联系我<span style='font-size:16px; font-weight:bold;'> (yex633967@gmail.com)</span><br>另外，欢迎加入我们的里程兑换交流群！",
        "searching" : "<img src='https://book.cathaypacific.com"+static_path+"common/skin/img/icons/cx/icon-loading.gif'> 请稍后...",
        "searching_w_cancel" : "<img src='https://book.cathaypacific.com"+static_path+"common/skin/img/icons/cx/icon-loading.gif'> 请稍后... (点我暂停)",
        "next_batch" : "载入更多...", "search_20" : "搜索 20 天可兑换航班", "search_all_cabins" : "批次搜索全舱等航班",
        "flights" : "可兑换航班", "nonstop":"直飞", "first" : "头等", "business" : "商务", "premium" : "豪经", "economy" : "经济",
        "first_full" : "头等舱", "business_full" : "商务舱", "premium_full" : "特选经济舱", "economy_full" : "经济舱",
        "date" : "日期", "no_flights" : "查无奖励机位", "expired" : "再搜索 20 天 (画面需重整)",
        "searching_cont" : "<img src='https://book.cathaypacific.com"+static_path+"common/skin/img/icons/cx/icon-loading.gif'> 请稍后... (窗口将会刷新)",
        "super" : "SUPERCharged Award Search", "error" : "不明错误... 再试一次", "bulk_batch" : "批次查询", "bulk_flights" : "航班",
        "new_version" : "有新版本可更新:", "login" : "提醒: 请先登录后再搜索。", "tab_retrieve_fail" : "无法取得密钥，请试着登出再重新登录。",
        "key_exhausted" : "密钥查询额度用尽，正尝试取得新密钥...", "getting_key" : "正在尝试取得 API 密钥...",
        "invalid_code": "目的地代码错误", "invalid_date": "日期错误",
        "maxsegments":"至多可选择 6 航段", "multi_book":"兑换多城市行程", "query":"查询", "delete":"删除",
        "book_multi":"多目的地行程预定",
        "advanced":"进阶功能<br>已启用", "loading":"查询中...", "hu_prompt":"你好像查询量很大...或许你该看看这里!",
        "prem_title":"进阶查询", "prem_intro":"在国泰订票页面辅助查询多个日期和路线。",
        "prem_feat1":"一次查询多个路线", "prem_text1":"支持多个出发地和目的地批次查找。",
        "prem_feat2":"查看路线机位", "prem_text2":"快速对照可兑换航班。",
        "prem_feat3":"批次查询多个路线", "prem_text3":"一键查询输入的航线组合。",
        "prem_feat4":"多城市行程(环球票)查询", "prem_text4":"勾选行程直接组成多城市查询。",
        "prem_feat5":"更多功能持续改进。", "prem_donate":"进阶查询工具已可使用。",
        "human":"国泰网站需要你证明你是真人：", "bot_check":"请解除国泰网站机器人检查",
        "mixed":"潜在混舱航班经由", "advanced_only_alpha":"进阶查询已启用。",
        "lang_toggle":"English", "points_confirm":"积分：请以预订页为准", "partner_points_confirm":"伙伴航司：积分需在预订页确认", "cx_points_estimate":"预估所需积分"
    };

    const searchBox = document.createElement("div");
    searchBox.innerHTML = `
        <div class='unelevated_form'>
            <div class='unelevated_title'>Award flight finder</div>
            <button type="button" class="lang_toggle">` + lang.lang_toggle + `</button>
            <div class='login_prompt hidden'><span class='unelevated_error'><a href="` + login_url + `">` + lang.login + `</a></span></div>
             <div class='unelevated_update hidden'><a target='_blank'>`+ lang.new_version + ` <span id='upd_version'>4.1.0</span> &raquo;</a></div>

            <div class='labels'>
                <a href="javascript:void(0);" class="switch"><svg height="16px" width="16px" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 365.352 365.352" transform="rotate(180)"><path d="M363.155,169.453l-14.143-14.143c-1.407-1.407-3.314-2.197-5.304-2.197 c-1.989,0-3.897,0.79-5.304,2.197l-45.125,45.125v-57.503c0-50.023-40.697-90.721-90.721-90.721H162.3c-4.143,0-7.5,3.358-7.5,7.5 v20c0,4.142,3.357,7.5,7.5,7.5h40.26c30.725,0,55.721,24.996,55.721,55.721v57.503l-45.125-45.125 c-1.407-1.407-3.314-2.197-5.304-2.197c-1.989,0-3.896,0.79-5.304,2.197l-14.143,14.143c-1.406,1.406-2.196,3.314-2.196,5.303 c0,1.989,0.79,3.897,2.196,5.303l82.071,82.071c1.465,1.464,3.385,2.197,5.304,2.197c1.919,0,3.839-0.732,5.304-2.197 l82.071-82.071c1.405-1.406,2.196-3.314,2.196-5.303C365.352,172.767,364.561,170.859,363.155,169.453z"></path> <path d="M203.052,278.14h-40.26c-30.725,0-55.721-24.996-55.721-55.721v-57.503l45.125,45.126 c1.407,1.407,3.314,2.197,5.304,2.197c1.989,0,3.896-0.79,5.304-2.197l14.143-14.143c1.406-1.406,2.196-3.314,2.196-5.303 c0-1.989-0.79-3.897-2.196-5.303l-82.071-82.071c-2.93-2.929-7.678-2.929-10.607,0L2.196,185.292C0.79,186.699,0,188.607,0,190.596 c0,1.989,0.79,3.897,2.196,5.303l14.143,14.143c1.407,1.407,3.314,2.197,5.304,2.197s3.897-0.79,5.304-2.197l45.125-45.126v57.503 c0,50.023,40.697,90.721,90.721,90.721h40.26c4.143,0,7.5-3.358,7.5-7.5v-20C210.552,281.498,207.194,278.14,203.052,278.14z"></path> </svg></a>
                <label class="labels_left"><span>From</span>
                    <input tabindex="1" type='text' id='uef_from' name='uef_from' placeholder='TPE' value='` + uef_from + `'><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="clear_from" viewBox="0 0 16 16"><path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"></path> </svg></a></label>
                <label class="labels_right"><span>Adults</span>
                    <input tabindex="4" type='number' inputmode='decimal' onClick='this.select();' id='uef_adult' name='uef_adult' placeholder='Adults' value='` + uef_adult + `'></label>
                <label class="labels_left"><span>To</span>
                    <input tabindex="2" type='text' id='uef_to' name='uef_to' placeholder='TYO' value='` + uef_to + `'><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="clear_to" viewBox="0 0 16 16"><path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"></path> </svg></label>
                <label class="labels_right"><span>Children</span>
                    <input tabindex="5" type='number' inputmode='decimal' onClick='this.select();' id='uef_child' name='uef_child' placeholder='Children' value='` + uef_child + `'></label>
                <label class="labels_left"><span>Date</span>
                    <input tabindex="3" class="uef_date" type="date" id="uef_date" name="uef_date"
                        min="` + toDashedDate(dateAdd(-1)) + `"
                        max="` + toDashedDate(dateAdd(365)) + `"
                        value="` + toDateInputValue(uef_date) + `"></label>
                <button class='uef_search'>` + lang.search + `</button>
            </div>
             <div class='unelevated_sub'><a target='_blank'>` + lang.coffee + `</a></div>
        </div>
        <div class='bulk_box'>
            <div class="bulk_results bulk_results_hidden">
                <div class="filters">
                    <label><input type="checkbox" id="filter_nonstop">${lang.nonstop}</label>
                    <label><input type="checkbox" id="filter_first" checked>${lang.first}</label>
                    <label><input type="checkbox" id="filter_business" checked>${lang.business}</label>
                    <label><input type="checkbox" id="filter_premium" checked>${lang.premium}</label>
                    <label><input type="checkbox" id="filter_economy" checked>${lang.economy}</label>
                </div>
                <table class='bulk_table show_first show_business show_premium show_economy'><thead><th class='bulk_date'>` + lang.date + `</th><th class='bulk_flights'>` + lang.flights + ` <span class='info-x info-f'>` + lang.first + `</span><span class='info-x info-j'>` + lang.business + `</span><span class='info-x info-p'>` + lang.premium + `</span><span class='info-x info-y'>` + lang.economy + `</span></th></thead><tbody></tbody></table>
            </div>
            <div class="bulk_footer">
                <div class="bulk_footer_container">
                    <button class='bulk_submit'>` + lang.search_20 + `</button>
                    <div class="bulk_error bulk_error_hidden"><span></span></div>
                </div>
            </div>
        </div>
        <div id="encbox"></div>
       `;

//============================================================
// Styles (Unchanged)
//============================================================

    const styleCss = `
        .unelevated_form * { box-sizing:border-box; -webkit-text-size-adjust: none;}
        .unelevated_form a, .bulk_box a { color:#2b4036; }
        .unelevated_form input:focus { outline: none; }
        .results_container { max-width: 900px; margin: 0 auto; padding: 20px 20px; }
        @media screen and (max-width: 500px) { .results_container { padding:20px 10px; } }
        .cont_query .modal {display:none !important;}
        .unelevated_form { position:relative;transition: margin-left 0.7s ease-out;z-index: 11; font-family: "GT Walsheim","Cathay Sans EN", CathaySans_Rg, sans-serif; border: 1px solid #bcbec0; margin:10px 0; background: #f9f9f9; padding: 8px 0px 8px 8px; border-top: 5px solid #2b4036; box-shadow: 0px 0px 7px rgb(0 0 0 / 20%);}
        .unelevated_form.uef_collapsed { margin-left:-90%;}
        .unelevated_title {font-weight: 400; font-size: 17px; font-family: "GT Walsheim","Cathay Sans EN", CathaySans_Rg, sans-serif; color: #2d2d2d; margin: 5px; height:26px;}
        .unelevated_title a {text-decoration:none; color: #2d2d2d;}
        .lang_toggle { position:absolute; right:16px; top:16px; border:1px solid #d9e4e1; background:#fff; color:#005f57; border-radius:999px; padding:6px 12px; font-weight:700; cursor:pointer; }
        .unelevated_form .autocomplete-items div:hover{ background-color: #e9e9e9; }
        .unelevated_form .autocomplete-active { background-color: DodgerBlue !important; color: #ffffff; }
        a.switch:active { margin-top: 40px; margin-left: -18px; }
        a.switch { display: inline-block; position: absolute; background: white; z-index: 15; margin-top: 38px; border: 1px solid #bcbec0; text-decoration: none; padding: 2px 10px; border-radius: 15px; left: 32.5%; margin-left: -19px; height: 22px; line-height: 16px; }
        a.switch svg path { fill: #AAA; }
        .unelevated_form .labels { display: flex; flex-wrap: wrap;}
        .unelevated_form .labels label { margin:0; display: inline-block; position: relative; width:50%; padding: 0px 8px 0px 0px; }
        .unelevated_form .labels label.labels_left {width:65%;}
        .unelevated_form .labels label.labels_right {width:35%;}
        .unelevated_form .labels label > span { position: absolute; top: 0px; left: 5px; color: #66686a; font-family: Cathay Sans EN, CathaySans_Rg, sans-serif; line-height: 25px; font-size: 10px;}
        .unelevated_form .labels input {  font-family: Cathay Sans EN, CathaySans_Rg, sans-serif; padding: 19px 5px 5px 5px; border-radius: 0px; border: 1px solid #bcbec0; display: inline-block; margin: 0px 8px 8px 0px; height: 45px; width: 100%; font-size:16px}
        svg.clear_from, svg.clear_to { position: absolute; right: 20px; top: 15px; opacity: 30%; }

        .unelevated_form button.uef_search { background-color: #2b4036; white-space:nowrap; overflow:hidden;text-overflow:ellipsis;border: none; color: white; display: inline-block;vertical-align: top; margin: 0px; height: 45px; width: calc(35% - 8px); font-size:15px}
        .unelevated_sub { line-height:25px; vertical-align:top;} .coffee_emoji {display:inline-block; line-height:25px; font-size: 25px; margin-left: 6px; vertical-align: top;}
        .unelevated_sub a { line-height:25px; vertical-align:top; font-family: Cathay Sans EN, CathaySans_Bd, sans-serif; font-size: 14px !important; text-decoration:underline dotted !important; margin: 0px; color: #ae4b4b !important; font-weight: bold;}
        .unelevated_sub a:after { content:none !important; }
        a.uef_toggle, a.uef_toggle:hover { background: #2b4036; display: block; position: absolute; right: -1px; top: -5px; padding-top:5px; width: 30px; text-align: center; text-decoration: none; color: white !important; padding-bottom: 5px; }
        a.uef_toggle:after {content:'«'} .uef_collapsed a.uef_toggle:after {content : '»'}
        .bulk_box {min-height: 60px; transition: margin-top 0.7s ease-out;background: #f9f9f9; border: 1px solid #bcbec0; box-shadow: 0px 0px 7px rgb(0 0 0 / 20%); margin-top: -11px !important; margin-bottom: 20px; z-index: 9; position: relative;}
        .bulk_box_hidden {position:relative; margin-top:-80px;}
        .bulk_results {transition: all 0.5s ease-out; min-height: 30px; margin: 0 10px 10px 10px;}
        .bulk_results_hidden { height:0; min-height:0; margin:0; overflow:hidden; transition: all 0.5s ease-out;}
        .filters { text-align: center; font-size: 12px; padding: 10px 0px 10px 0px; position: sticky; top: 0; z-index: 10; background: #f9f9f9; border-bottom: 1px solid #c6c2c1; }
        .filters input{ vertical-align: -2px; margin-right:5px; margin-left:10px; }
        .filters label { display:inline-block; }
        .bulk_table { width:100%; border: 1px solid #c6c2c1; margin-top: -1px; font-size: 12px; border-spacing: 0; border-collapse: collapse; }
        .bulk_table th { text-align:center !important; font-weight:bold; background: #ebedec; line-height:17px; font-size: 12px; }
        .bulk_table td { background:white; }
        .bulk_table tr:nth-child(even) td { background:#f9f9f9; }
        .bulk_table th, .bulk_table td { border: 1px solid #c6c2c1; padding: 5px; }
        .bulk_table .bulk_date { width:80px; text-align:center; }
        .bulk_table .bulk_date a { text-decoration:underline !important; font-family: "Cathay Sans EN", CathaySans_Md, sans-serif; font-weight: 400; display:block;margin-bottom:5px;}
        .unelevated_container .bulk_table td.bulk_flights > div { display:none; }
        .unelevated_container .bulk_table td.bulk_flights > div:first-of-type { display:block; }
        .unelevated_container .bulk_table td.bulk_flights .flight_title { display:none; }
        .bulk_table td.bulk_flights { padding:5px 5px 0 5px; font-family: "Cathay Sans EN", CathaySans_Rg, sans-serif; font-weight: 400; line-height:0px; }
        .bulk_table td.bulk_flights .flight_list:empty:after { display: block; height: 24px; content: "` + lang.no_flights+ `"; margin-bottom: 5px; margin-top: -3px; margin-left: 10px; font-family: "Cathay Sans EN", CathaySans_Rg, sans-serif; font-weight: 400; line-height: 24px; color: #AAA;}
        .bulk_table td.bulk_flights .flight_list span.bulk_response_error { line-height: 24px;}
        .bulk_table .bulk_flights .bulk_no_flights { display:block;padding-bottom:5px; }
        .bulk_response_error { display:block;padding-bottom:5px;padding-left:5px;padding-right:5px; color:red; }
        .bulk_table .flight_title { display: block; background: #dde8e8; font-size: 12px; line-height: 15px; padding: 3px 7px; margin-bottom: 7px; margin-top: 2px; border-bottom: 3px solid #2b4036; position:relative; }
        .bulk_go_book { float:right; margin-right:5px; margin-left:10px; font-weight:bold;}
        a.bulk_go_book * {  pointer-events: none; }
        .flight_wrapper { position:relative; display:inline-block; }
        .flight_info { position: absolute; left: 0; top: 37px; background: #e0e0e0; border: 1px solid #bbb; padding: 6px 10px; display: none; line-height: 18px; z-index: 15; border-radius: 5px; white-space: nowrap; box-shadow: 0px 0px 5px rgb(0 0 0 / 30%); }
        .flight_info > span { display:block; }
        .flight_info span.info_flight { font-weight:bold; font-family: CathaySans_Bd, sans-serif; }
        .info_dept > span, .info_arr > span { display: inline-block; width: 50px; color: #999; font-weight: bold; font-family: CathaySans_Md, sans-serif; }
        span.info_transit, span.info_duration { margin: 8px 0px; background: #ededed; border-radius: 5px; padding: 2px 8px; text-align: center; font-size: 11px; color: #888; }
        span.info_duration { margin-bottom:5px; }
        .flight_item.active + .flight_info { display:block; }
        .flight_item { transition: all 0.5s ease-in; background: #e0e0e0; line-height:15px !important; border-radius: 5px; margin-bottom: 5px; white-space: nowrap; font-size:12px; font-family: "GT Walsheim","Cathay Sans EN", CathaySans_Rg, sans-serif; font-weight:400; position:relative; display: inline-block; overflow:hidden; max-width:0px; padding: 6px 0px; margin-right: 0px; }
        .flight_item span.stopover { border-radius:5px;padding: 2px 4px; color: #909090 !important; display: inline-block; background: white; font-size: 10px; margin: 0px 4px !important; line-height: 11px; }
        .flight_item.direct { background: #cbe0cf; }
        .flight_item img { line-height: 15px; max-height: 15px; vertical-middle: middle; margin-right: 2px; max-width: 20px;}
        .show_first .flight_item[data-f="1"], .show_business .flight_item[data-j="1"], .show_premium .flight_item[data-p="1"], .show_economy .flight_item[data-y="1"] { max-width:520px; padding: 6px 6px; margin-right: 6px; }
        .nonstop_only .flight_item[data-direct="0"] { max-width:0px; padding:6px 0px; margin-right: 0px; }
        span.bulk_j { background: #002e6c;}
        span.bulk_f { background: #832c40;}
        span.bulk_p { background: #487c93;}
        span.bulk_y { background: #016564;}
        .flight_item span.flight_num{ line-height: 16px; vertical-align: middle; height: 16px; display: inline-block; padding: 2px 0; }
        .flight_item span.bulk_j, .flight_item span.bulk_f, .flight_item span.bulk_p, .flight_item span.bulk_y { color: white; border-radius: 5px; font-size:10px; overflow:hidden; transition: all 0.5s ease-in; display:inline-block; vertical-align:top; height: 16px; line-height: 16px; max-width:0px; padding: 2px 0px; margin-left: 0px; }
        .show_first span.bulk_f, .show_business span.bulk_j, .show_premium span.bulk_p, .show_economy span.bulk_y { max-width:25px; padding: 2px 5px; margin-left: 3px; }
        .flight_item .chevron { vertical-align: top; display: inline-block; padding: 2px 0 2px 0px; height: 16px; opacity: 0.5; margin-right: -2px; margin-left: -2px; }
        .flight_item .chevron svg { vertical-align: top; transform:rotate(-90deg); }
        .flight_item.active .chevron svg { transform:rotate(0deg); }
        .flight_item * {  pointer-events: none; }
        .flight_points { display:inline-block; margin-left:6px; padding:2px 6px; background:#fff; border-radius:5px; color:#36514b; font-size:10px; line-height:16px; vertical-align:top; }
        .bulk_footer{ min-height: 45px; position:sticky; bottom:0;}
        .bulk_footer .bulk_footer_container { padding: 10px; background: #f9f9f9; margin: 0; }
        .bulk_footer.bulk_sticky .bulk_footer_container { border-top: 1px solid #c6c2c1; box-shadow: 0px 0px 7px rgb(0 0 0 / 20%); }
        @media screen and (max-width: 500px) { .bulk_footer.bulk_sticky .bulk_footer_container  { max-width: 838px;} }
        button.bulk_submit {position:relative;background-color: #2b4036; border: none; color: white; vertical-align: middle; margin: 0px auto; height: 45px; line-height: 35px; padding: 5px 0; width: 100%; display: block; font-family: "GT Walsheim","Cathay Sans EN", CathaySans_Rg, sans-serif !important;font-size:15px}
        .bulk_submit img, button.uef_search img {line-height: 35px; height: 25px; width:auto; display: inline-block; margin-right: 10px; vertical-align: -7px;}
        .bulk_searching, .uef_search.searching  {background-color: #b9cdc9 !important;}
        .col-select-departure-flight > .row:last-of-type { padding-bottom: 140px; }
        span.info-x { border-radius: 5px; padding: 2px 5px; margin-left: 5px; color:white; font-size:10px; font-family: CathaySans_Md, Cathay Sans EN; font-weight: 400; }
        span.info-f { background: #832c40;}
        span.info-j { background: #002e6c;}
        span.info-p { background: #487c93;}
        span.info-y { background: #016564;}
        .unelevated_update.hidden { display:none; }
        .unelevated_update { border-radius: 5px; background: #f27878; padding: 5px 10px; margin: 0px 8px 10px 0; text-align: center; }
        .unelevated_update a { color:white !important; } .unelevated_update a:after { content:none !important; }
        .unelevated_update a span { font-weight:bold; font-family: "GT Walsheim","Cathay Sans EN", CathaySans_Md, sans-serif; }
        .unelevated_update.update_show { display:block; }
        .login_prompt {  height: 40px; line-height: 20px; overflow: hidden; transition: all 0.5s ease-out; margin-bottom: 10px; }
        .login_prompt.hidden { height: 0; overflow:hidden; margin: 0; }
        a.search_multicity { position: absolute; right: 15px; top: 6px; height: 20px; line-height: 20px !important; font-size: 12px !important; font-weight: bold !important; display:none; }
        .multi_on .search_multicity { position: absolute; right: 15px; top: 6px; height: 20px; line-height: 20px !important; font-size: 12px !important; font-weight: bold !important; display:block; }
        .leg{ color: #ae4b4b !important; font-weight:bold;}
        span.unelevated_error { padding: 10px 0 10px 10px; line-height:20px; max-height:100%; display: block; background: #ffd2d2; border-radius: 5px; margin: 0 10px 5px 0; text-align: center; color: #b54545; font-weight:bold; font-size:14px;}
        span.unelevated_error a {padding: 0; margin: 0;  text-decoration: underline; line-height: 20px; max-height: 100%; height: 24px; display: block; background: #ffd2d2; border-radius: 5px; margin: 0 10px 5px 0; text-align: center; color: #b54545;font-family: CathaySans_Md, Cathay Sans EN; font-weight: 400;}
        .bulk_error span {padding: 5px; line-height: 20px; height: 20px; max-height: 100%; display: block; background: #eae6d9; border-radius: 5px; text-align: center; color: #b54545; margin-top: 10px; font-size: 12px; transition: all 0.5s ease-out;font-family: CathaySans_Md, Cathay Sans EN; font-weight: 400;}
        .bulk_error_hidden span { height:0; margin-top: 0; overflow:hidden; padding:0;}
        .unelevated_form .autocomplete { position: relative; display: inline-block; }
        .unelevated_form .autocomplete-items { position: absolute; border: 1px solid #bcbec0; border-top: none; z-index: 99; top: 100%; left: 0; right: 8px;; margin-top:-8px; max-height:200px; overflow:scroll; background:white; }
        .unelevated_form .autocomplete-items div { padding: 5px; cursor: pointer; background-color: #fff; border-bottom: 1px solid #e4e4e4; font-size:12px; font-weight: normal; font-family: "Cathay Sans EN", CathaySans_Rg, sans-serif; white-space: nowrap; overflow: hidden; }
        .unelevated_form .autocomplete-items div span.sa_code { margin-left:5px; display:inline-block; width:30px; font-weight:normal; }
        .unelevated_form .autocomplete-items div span.sc_code { color:#888; display:inline-block; margin-left:10px; font-weight:normal; }
        .unelevated_form .autocomplete-items div:hover { background-color: #e9e9e9; }
        .unelevated_form .autocomplete-active, .unelevated_form div.autocomplete-active span.sc_code { background-color: DodgerBlue !important; color: #ffffff; }
        #planner_routes { background: #f9f9f9; padding: 5px 10px; margin-bottom: -10px; border: 1px solid #bcbec0; box-shadow: 0px 0px 7px rgb(0 0 0 / 20%); border-bottom: none; }
        #planner_routes:empty { display:none; }
        a.planner_route { color: #016564; display: inline-block; margin-right: 10px; font-size: 14px; }
        /* Minimal modern interface */
        .unelevated_form, .bulk_box {
          font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          border: 1px solid #e3e9e7;
          background: #fff;
          box-shadow: 0 12px 32px rgb(20 54 48 / 10%);
        }
        .unelevated_form {
          position: relative;
          overflow: hidden;
          border-top: 0;
          border-radius: 18px;
          margin: 20px 0 12px;
          padding: 24px;
        }
        .unelevated_form::before {
          content: "";
          position: absolute;
          inset: 0 0 auto;
          height: 5px;
          background: linear-gradient(90deg, #005f57, #2b7a71);
        }
        .unelevated_title {
          color: #183b35;
          font-size: 21px;
          font-weight: 700;
          height: auto;
          letter-spacing: -.02em;
          margin: 8px 0 22px;
        }
        .unelevated_form .labels { gap: 12px; }
        .unelevated_form .labels label.labels_left,
        .unelevated_form .labels label.labels_right {
          width: calc(50% - 6px);
          padding: 0;
        }
        .unelevated_form .labels input {
          height: 58px;
          margin: 0;
          padding: 24px 13px 8px;
          border: 1px solid #d9e4e1;
          border-radius: 10px;
          background: #fbfcfc;
          color: #183b35;
          font-size: 16px;
          transition: border-color .2s, box-shadow .2s;
        }
        .unelevated_form .labels input:focus {
          border-color: #14776d;
          box-shadow: 0 0 0 4px rgb(20 119 109 / 12%);
        }
        .unelevated_form .labels label > span {
          top: 6px;
          left: 13px;
          color: #687b76;
          font-size: 11px;
          font-weight: 600;
          letter-spacing: .03em;
          text-transform: uppercase;
        }
        svg.clear_from, svg.clear_to { right: 13px; top: 21px; }
        a.switch {
          background: #fff;
          border-color: #d9e4e1;
          box-shadow: 0 2px 8px rgb(20 54 48 / 12%);
        }
        .unelevated_form button.uef_search,
        button.bulk_submit {
          width: calc(50% - 6px);
          height: 58px;
          border-radius: 10px;
          background: #006b61;
          font-size: 15px;
          font-weight: 700;
          transition: background .2s, transform .2s;
        }
        .unelevated_form button.uef_search:hover,
        button.bulk_submit:hover { background: #00564f; }
        .unelevated_form button.uef_search:active,
        button.bulk_submit:active { transform: translateY(1px); }
        .unelevated_sub { margin-top: 16px; color: #71827e; font-size: 12px; }
        .unelevated_sub a { color: #50716a !important; font-size: 12px !important; font-weight: 500; }
        .bulk_box { margin-top: 0 !important; overflow: hidden; border-radius: 18px; }
        .bulk_results { margin: 0 18px 12px; }
        .filters { padding: 16px 0; background: #fff; border-bottom-color: #edf1f0; }
        .bulk_table { overflow: hidden; border-color: #e3e9e7; border-radius: 10px; }
        .bulk_table th { background: #f3f7f6; color: #36514b; }
        .bulk_table th, .bulk_table td { border-color: #e3e9e7; padding: 9px; }
        .bulk_footer .bulk_footer_container { padding: 18px; background: #fff; }
        button.bulk_submit { width: 100%; }
        @media screen and (max-width: 600px) {
          .unelevated_form { padding: 18px; border-radius: 14px; }
          .unelevated_form .labels label.labels_left,
          .unelevated_form .labels label.labels_right,
          .unelevated_form button.uef_search { width: 100%; }
          a.switch { left: calc(100% - 29px); margin-top: 38px; }
        }
    `;

    addCss(`.captcha_wrapper { position: fixed; top: 150px; left: 50%; width: 300px; height: 200px; background: white; z-index: 20; padding: 10px; margin-left: -150px; box-shadow: 0px 0px 5px; border-radius: 5px; } .human_check { margin: 10px 20px 20px 20px; text-align: center; } `, document.body)

//============================================================
// Form Listeners
//============================================================

    let btn_search, btn_batch;
    let input_from, input_to, input_date, input_adult, input_child;
    let clear_from, clear_to;
    let div_filters;
    let div_update, div_login_prompt, div_bulk_box, div_footer,div_ue_container;
    let div_table, div_table_body;
    let premium_switch;

    function assignElemets(){
        log("assignElemets()");
        btn_search =   shadowRoot.querySelector(".uef_search");
        btn_batch =      shadowRoot.querySelector(".bulk_submit");
        input_from =    shadowRoot.querySelector("#uef_from");
        input_to =      shadowRoot.querySelector("#uef_to");
        input_date =    shadowRoot.querySelector("#uef_date");
        input_adult =   shadowRoot.querySelector("#uef_adult");
        input_child =   shadowRoot.querySelector("#uef_child");
        clear_from =    shadowRoot.querySelector(".clear_from");
        clear_to =      shadowRoot.querySelector(".clear_to");
        div_filters =        shadowRoot.querySelector(".filters");
        div_update =        shadowRoot.querySelector(".unelevated_update");
        div_login_prompt =  shadowRoot.querySelector(".login_prompt");
        div_bulk_box =        shadowRoot.querySelector(".bulk_box");
        div_footer =        shadowRoot.querySelector(".bulk_footer");
        div_ue_container =  shadowRoot.querySelector(".unelevated_form");
        div_table =         shadowRoot.querySelector(".bulk_table");
        div_table_body =    shadowRoot.querySelector(".bulk_table tbody");
        premium_switch =    shadowRoot.querySelector(".prem_title");
    }

    function addFormListeners(){
        log("addFormListeners()");
        btn_search.addEventListener("click", function(e) {
            uef_from =  value_set("uef_from",input_from.value);
            uef_to =    value_set("uef_to",input_to.value);
            uef_date =  value_set("uef_date",normaliseDate(input_date.value));
            uef_adult = value_set("uef_adult",input_adult.value);
            uef_child = value_set("uef_child",input_child.value);
            regularSearch([{from:uef_from.substring(0,3), to:uef_to.substring(0, 3), date:uef_date}], {adult:uef_adult, child:uef_child}, "Y", (uef_to.length > 3 ? true : false), false);
        });

        btn_batch.addEventListener("click", function(e) {
            autoScroll = true;
            bulk_click();
        });

        shadowRoot.querySelector(".lang_toggle").addEventListener("click", function() {
            value_set("ui_lang", ui_lang == "zh" ? "en" : "zh");
            window.location.reload();
        });

        shadowRoot.querySelector(".switch").addEventListener('click', function(e) {
            let from = input_from.value;
            let to = input_to.value;
            input_from.value = to;
            input_to.value = from;
            route_changed = true;
        });

        [input_from, input_to].forEach( item => { item.addEventListener('keyup', function(e) {
            // Allow comma-separated airport codes for batch route searches.
            if (e.keyCode == 32 || e.keyCode == 188 || e.keyCode == 13){
                if(e.keyCode == 13) this.value += ",";
                this.value = this.value.toUpperCase().split(/[ ,]+/).join(',');
            }
        }) });

        input_from.addEventListener("change", function(e) {
            route_changed = true;
            batchLabel(lang.bulk_batch + " " + input_from.value + " - " + input_to.value + " " + lang.bulk_flights);
            let dest = this.value.match(/[A-Z]{3}$/);
            if (dest) getDestinations(dest[0]);
        });

        input_to.addEventListener("change", function(e) {
            route_changed = true;
            batchLabel(lang.bulk_batch + " " + input_from.value + " - " + input_to.value + " " + lang.bulk_flights);
        });

        let inFocus = false;

        [input_from, input_to].forEach( item => { item.addEventListener('focus', function(e){
            if(this.value.length > 0) this.value = this.value + ",";
        }) });

        [input_from, input_to].forEach( item => { item.addEventListener('click', function(e){
            if(!inFocus) this.setSelectionRange(this.value.length,this.value.length);
            inFocus = true;
        }) });

        [input_from, input_to].forEach( item => { item.addEventListener('blur', function(e) {
            inFocus = false;
            this.value = this.value.toUpperCase().split(/[ ,]+/).join(',').replace(/,+$/, "")
            this.dispatchEvent(new Event('change'));
            checkCities(this);
        }) });

        input_date.addEventListener("change", function() {
            if (!isValidDate(normaliseDate(this.value))) {
                alert(lang.invalid_date);
                this.value = toDateInputValue(uef_date);
            } else {
                route_changed = true;
            }
        });

        clear_from.addEventListener("click", function(e) { input_from.value = ""; });
        clear_to.addEventListener("click", function(e) { input_to.value = ""; });

        div_table.addEventListener("click",function(e){
            var key;
            if(e.target.dataset.book) {
                stop_batch();
                e.target.innerText = lang.loading;
                const bookedFrom = e.target.dataset.from ? e.target.dataset.from : uef_from.substring(0, 3);
                const bookedTo = e.target.dataset.dest ? e.target.dataset.dest : uef_to.substring(0, 3);
                const bookedDate = normaliseDate(e.target.dataset.date);
                uef_from = value_set("uef_from", bookedFrom);
                uef_to = value_set("uef_to", bookedTo);
                uef_date = value_set("uef_date", bookedDate);
                regularSearch([{from: bookedFrom, to: bookedTo, date: bookedDate}], {adult:uef_adult, child:uef_child}, "Y", false, false, false)
            } else if (e.target.classList.contains("flight_item")) {
                if(e.target.classList.contains("active")) {
                    e.target.classList.remove("active");
                } else {
                    shadowRoot.querySelectorAll(".flight_item").forEach(function(elm){
                        elm.classList.remove('active');
                    });
                    e.target.classList.add("active");
                }
            }
        });

        document.addEventListener("scroll", function() {
            shadowRoot.querySelectorAll(".flight_item").forEach(function(elm){
                elm.classList.remove('active');
            });
        });

        div_filters.querySelectorAll("input").forEach(item =>{ item.addEventListener("click",function(e){
            if(e.target.id == "filter_nonstop"){
                if(e.target.checked){ div_table.classList.add("nonstop_only") } else { div_table.classList.remove("nonstop_only") }
            } else if (e.target.id == "filter_first"){
                if(e.target.checked){ div_table.classList.add("show_first") } else { div_table.classList.remove("show_first") }
            } else if (e.target.id == "filter_business"){
                if(e.target.checked){ div_table.classList.add("show_business") } else { div_table.classList.remove("show_business") }
            } else if (e.target.id == "filter_premium"){
                if(e.target.checked){ div_table.classList.add("show_premium") } else { div_table.classList.remove("show_premium") }
            } else if (e.target.id == "filter_economy"){
                if(e.target.checked){ div_table.classList.add("show_economy") } else { div_table.classList.remove("show_economy") }
            }
        })});

    };

//============================================================
// Data Retrievers & Application Logic (Unchanged)
//============================================================

    const airports = { origins:[], dest:[] };
    unsafeWindow.innerFunc = function innerFunc(){ console.log("innerfunc"); };

    function getOrigins(){
        log("getOrigins()");
        httpRequest({
            method: "GET",
            url: "https://api.cathaypacific.com/redibe/airport/origin/" + (browser_lang == "zh" ? (browser_country == "CN" ? "sc" : "zh") : "en") + "/",
            onload: function(response) {
                var data = JSON.parse(response.responseText);
                if(data.airports){
                    data.airports.forEach(airport => {
                        airports.origins[airport.airportCode] = {
                            airportCode:airport.airportCode, shortName:airport.shortName, countryName:airport.countryName
                        }
                    });
                } else { airports.origins = []; }
            }
        });
    }

    function getDestinations(from){
        if (!airports.origins[from]) return;
        log("getDestinations()");
        httpRequest({
            method: "GET",
            url: "https://api.cathaypacific.com/redibe/airport/destination/" + from + "/" + (browser_lang == "zh" ? (browser_country == "CN" ? "sc" : "zh") : "en") + "/",
            onload: function(response) {
                var data = JSON.parse(response.responseText);
                if(data.airports){
                    data.airports.forEach(airport => {
                        airports.dest[airport.airportCode] = {
                            airportCode:airport.airportCode, shortName:airport.shortName, countryName:airport.countryName
                        }
                    });
                } else { airports.dest = []; }
            }
        });
    }

    function batchLabel(label){ if(shadowRoot.querySelector(".bulk_submit")) { shadowRoot.querySelector(".bulk_submit").innerHTML = label; } }
    function batchError(label){
        if(label) {
            shadowRoot.querySelector(".bulk_error span").innerHTML = label;
            shadowRoot.querySelector(".bulk_error").classList.remove("bulk_error_hidden");
        } else { shadowRoot.querySelector(".bulk_error").classList.add("bulk_error_hidden"); }
    }

    function autocomplete(inp, list) {
      var currentFocus;
      inp.addEventListener("input", function(e) { newAC(this,e); });
      inp.addEventListener("keydown", function(e) {
          var x = shadowRoot.getElementById(this.id + "autocomplete-list");
          if (x) x = x.getElementsByTagName("div");
          if (e.keyCode == 40) { currentFocus++; addActive(x); }
          else if (e.keyCode == 38) { currentFocus--; addActive(x); }
          else if (e.keyCode == 13) { e.preventDefault(); closeAllLists(); if (currentFocus > -1 && x) x[currentFocus].click(); }
          else if (e.keyCode == 32 || e.keyCode == 9) { closeAllLists(); if (x) x[0].click(); }
      });
      function addActive(x) { if (!x) return false; removeActive(x); if (currentFocus >= x.length) currentFocus = 0; if (currentFocus < 0) currentFocus = (x.length - 1); x[currentFocus].classList.add("autocomplete-active"); }
      function removeActive(x) { for (var i = 0; i < x.length; i++) { x[i].classList.remove("autocomplete-active"); } }
      function closeAllLists(elmnt) { var x = shadowRoot.querySelectorAll(".autocomplete-items"); for (var i = 0; i < x.length; i++) { if (elmnt != x[i] && elmnt != inp) { x[i].parentNode.removeChild(x[i]); } } }
      function checkLocale(code){ return code.replace(atob("VGFpd2FuIENoaW5h"), atob("VGFpd2Fu")).replace(decodeURI(atob("JUU0JUI4JUFEJUU1JTlDJThCJUU1JThGJUIwJUU3JTgxJUEz")), decodeURI("%E5%8F%B0%E7%81%A3")); }

      function newAC(elm,e){
          var arr = airports[list] || [];
          var a, b, c, val = elm.value;
          closeAllLists();
          val = elm.value.match(/[^,]+$/) ? elm.value.match(/[^,]+$/)[0] : false;
          if (!val) { return false;}
          currentFocus = -1;
          a = document.createElement("DIV");
          a.setAttribute("id", elm.id + "autocomplete-list");
          a.setAttribute("class", "autocomplete-items");
          elm.parentNode.appendChild(a);
          var sep = document.createElement("span");
          sep.style.display="none";
          sep.classList.add("ac_separator");
          a.appendChild(sep);
          var favs = ["TPE","TSA","KHH","RMQ","TYO","HND","NRT","KIX","ITM","CTS","FUK","NGO","OKA","ICN","PUS","GMP","CJU","HKG","MFM","BKK","CNX","HKT","CGK","DPS","SUB","KUL","BKI","PEN","DAD","HAN","SGN","CEB","MNL","SIN","PNH","DEL","BOM","DXB","DOH","TLV","BCN","MAD","MXP","CDG","ZRH","MUC","FCO","FRA","AMS","LHR","LGW","LON","MAN","BOS","JFK","YYZ","ORD","IAD","YVR","SFO","LAX","SAN","SEA","JNB","PER","SYD","BNE","MEL","AKL","HEL","BLR","SHA","PVG","PEK","CAN","KTM","ADL","CPT","ATH","IST","SOF","VCE","BUD","PRG","VIE","BER","WAW","KBP","CPH","DUS","BRU","OSL","ARN","DUB","MIA","ATL","IAH","DFW","PHL","CMN","LAS","SJC","DEN","AUS","MSY","MCO","EWR","NYC","LIS","OPO","SPU","DBV","ZAG","MLE","LIM","BOG","CNS","GRU","SCL","GIG","EZE","MEX","CUN"];
          Object.keys(arr).forEach(key => {
            var airportCode = arr[key].airportCode;
            var countryName = checkLocale(arr[key].countryName);
            var shortName = arr[key].shortName;
            if(airportCode.length > 3) return;
            if (val.toUpperCase() == airportCode.substr(0, val.length).toUpperCase() || val.toUpperCase() == countryName.substr(0, val.length).toUpperCase() || val.toUpperCase() == shortName.substr(0, val.length).toUpperCase() ) {
            var sa = (airportCode.substr(0, val.length).toUpperCase() == val.toUpperCase()) ? val.length : 0;
            var se = (shortName.substr(0, val.length).toUpperCase() == val.toUpperCase()) ? val.length : 0;
            var sc = (countryName.substr(0, val.length).toUpperCase() == val.toUpperCase()) ? val.length : 0;
              b = document.createElement("DIV");
              c = "<span class='sa_code'><strong>" + airportCode.substr(0, sa) + "</strong>" + airportCode.substr(sa) + "</span>";
              c += "<span class='sc_code'><strong>" + shortName.substr(0, se) + "</strong>" + shortName.substr(se) + "";
              c += " - <strong>" + countryName.substr(0, sc) + "</strong>" + countryName.substr(sc) + "</span></span><input type='hidden' value='" + airportCode + "'>";
              b.dataset.city = airportCode;
              b.innerHTML = c;
              b.addEventListener("click", function(e) {
                  inp.value = [inp.value.replace(/([,]?[^,]*)$/,""),this.dataset.city].filter(Boolean).join(",");
                  inp.dispatchEvent(new Event('change'));
                  closeAllLists();
              });
              if(["TPE","KHH","HKG"].includes(airportCode)){ a.prepend(b); }
              else if(favs.includes(airportCode)) { a.insertBefore(b, sep); }
              else { a.appendChild(b); }
            }
          });
      }
      document.addEventListener("click", function (e) { if (e.target != inp) closeAllLists(e.target); });
    }

    function elevate(){
        log("elevate()");
        input_from.setAttribute('placeholder','TPE,HKG');
        input_to.setAttribute('placeholder','TYO,LHR,SFO');
    }

    let searching, stop_search = false;
    function resetSearch(){ searching = false; batchLabel(lang.search_20); shadowRoot.querySelector(".bulk_submit").classList.remove("bulk_searching"); }
    let remaining_days = 20;

    function stop_batch(){
        log("Batch Clicked. Stopping Search.");
        stop_search = true;
        searching = false;
        shadowRoot.querySelector(".bulk_submit").innerText = lang.next_batch;
        shadowRoot.querySelector(".bulk_submit").classList.remove("bulk_searching");
        batchError(false);
        remaining_days = 20;
    }

    function bulk_click(single_date = false){
        shadowRoot.querySelector(".bulk_results").classList.remove("bulk_results_hidden");
        if(!searching) {
            log("Batch Clicked. Starting Search.");
            uef_from = value_set("uef_from",input_from.value);
            uef_to = value_set("uef_to",input_to.value);
            uef_date = value_set("uef_date",normaliseDate(input_date.value));
            uef_adult = value_set("uef_adult",input_adult.value);
            uef_child = value_set("uef_child",input_child.value);
            btn_batch.innerHTML = lang.searching_w_cancel;
            btn_batch.classList.add("bulk_searching");
            bulk_search(single_date);
        } else { stop_batch(); }
    }

    function checkCities(elem){
        log("checkCities()");
        setTimeout(function() {
            var cities = elem.value.split(",");
            var errorcities = [];
            cities = cities.filter(city => {
                if(city.match(/^[A-Z]{3}$/)) { return true; }
                else { errorcities.push(city); return false; }
            })
            if(errorcities.filter(Boolean).length > 0) {
                elem.value = cities.join(",");
                elem.dispatchEvent(new Event('change'));
                alert("Invalid Airport" + (errorcities.filter(Boolean).length > 1 ? "s" : "") + " Removed: " + errorcities.filter(Boolean).join(","));
            }
        }, 500);
    }

    function checkLogin(){ return; }

    function newQueryPayload(route = {from: "HND", to: "ITM", date: dateAdd(14)}, passengers = {adult:1, child:0}, cabinclass ="Y",oneway = false, flexible = "false") {
        log("newQueryPayload()");
        const target = new URL('https://api.cathaypacific.com/redibe/IBEFacade');
        const params = new URLSearchParams();
        params.set('ACTION', 'RED_AWARD_SEARCH');
        params.set('ENTRYPOINT', 'https://www.cathaypacific.com/cx/' + lang.el + '_' + lang.ec + '/book-a-trip/redeem-flights/redeem-flight-awards.html');
        params.set('ENTRYLANGUAGE', lang.el);
        params.set('ENTRYCOUNTRY', lang.ec);
        params.set('RETURNURL', 'https://www.cathaypacific.com/cx/' + lang.el + '_' + lang.ec + '/book-a-trip/redeem-flights/redeem-flight-awards.html?recent_search=ow');
        params.set('ERRORURL', 'https://www.cathaypacific.com/cx/' + lang.el + '_' + lang.ec + '/book-a-trip/redeem-flights/redeem-flight-awards.html?recent_search=ow');
        params.set('CABINCLASS', cabinclass);
        params.set('BRAND', 'CX');
        params.set('ADULT', passengers.adult || 1);
        params.set('CHILD', passengers.child || 0);
        params.set('FLEXIBLEDATE', flexible);
        params.set('ORIGIN[1]', route.from);
        params.set('DESTINATION[1]', route.to);
        params.set('DEPARTUREDATE[1]', route.date);
        params.set('LOGINURL', 'https://www.cathaypacific.com/cx/' + lang.el + '_' + lang.ec + '/sign-in.html?loginreferrer=https%3A%2F%2Fwww.cathaypacific.com%2Fcx%2F' + lang.el + '_' + lang.ec + '%2Fbook-a-trip%2Fredeem-flights%2Fredeem-flight-awards.html%3Fauto_submit%3Dtrue%26recent_search%3Dow%26vs%3D2');
        target.search = params.toString();
        return target;
    }

    function newMultiPayload(routes, passengers, cabinclass = "Y") {
        log("newMultiPayload()");
        const target = new URL('https://api.cathaypacific.com/redibe/IBEFacade');
        const params = new URLSearchParams();
        params.set('ACTION', 'RED_AWARD_SEARCH');
        params.set('ENTRYPOINT', 'https://www.cathaypacific.com/cx/' + lang.el + '_' + lang.ec + '/book-a-trip/redeem-flights/redeem-flight-awards.html');
        params.set('ENTRYLANGUAGE', lang.el);
        params.set('ENTRYCOUNTRY', lang.ec);
        params.set('RETURNURL', 'https://www.cathaypacific.com/cx/' + lang.el + '_' + lang.ec + '/book-a-trip/redeem-flights/redeem-flight-awards.html?recent_search=mc');
        params.set('ERRORURL', 'https://www.cathaypacific.com/cx/' + lang.el + '_' + lang.ec + '/book-a-trip/redeem-flights/redeem-flight-awards.html?recent_search=mc');
        params.set('CABINCLASS', cabinclass);
        params.set('BRAND', 'CX');
        params.set('ADULT', passengers.adult || 1);
        params.set('CHILD', passengers.child || 0);
        params.set('FLEXIBLEDATE', 'false');
        for (var i = 0; i < routes.length; i++) {
            params.set('ORIGIN['+(i+1)+']', routes[i].from);
            params.set('DESTINATION['+(i+1)+']', routes[i].to);
            params.set('DEPARTUREDATE['+(i+1)+']', routes[i].date);
        }
        params.set('LOGINURL', 'https://www.cathaypacific.com/cx/' + lang.el + '_' + lang.ec + '/sign-in.html?loginreferrer=https%3A%2F%2Fwww.cathaypacific.com%2Fcx%2F' + lang.el + '_' + lang.ec + '%2Fbook-a-trip%2Fredeem-flights%2Fredeem-flight-awards.html%3Fauto_submit%3Dtrue%26recent_search%3Dow%26vs%3D2');
        target.search = params.toString();
        return target;
    }

    function response_parser(response, regex){
        var result = response.match(regex);
        try { result = JSON.parse(result[1]); } catch (e) { result = false; }
        return result;
    }

     function newTabID(callback){
        log("Creating New Request Parameters...");
        let parameters = {};
        if (requestParams.ENC) {
            parameters.SERVICE_ID = "1"; parameters.LANGUAGE = "TW"; parameters.EMBEDDED_TRANSACTION = "AirAvailabilityServlet";
            parameters.SITE = "CXAWCXAW"; parameters.ENC = requestParams.ENC; parameters.ENCT = "2"; parameters.ENTRYCOUNTRY = ""; parameters.ENTRYLANGUAGE = "";
        } else { alert("Error, No ENC."); return; }
        var form_data = "";
        for ( var key in parameters ) { form_data = form_data + key + "="+ parameters[key] + "&"; }
        log("Requesting New Tab ID...");
        httpRequest({
            method: "POST", url: "https://book.cathaypacific.com/CathayPacificAwardV3/dyn/air/booking/availability",
            headers: { "Content-Type": "application/x-www-form-urlencoded" }, data: form_data, withCredentials: "true",
            onreadystatechange: function(response) {
                var errorBOM = ""; var errorMessage = lang.tab_retrieve_fail;
                if(response.readyState == 4 && response.status == 200) {
                    var data = response.responseText;
                    requestVars = response_parser(data, /requestParams = JSON\.parse\(JSON\.stringify\('([^']+)/);
                    if(!requestVars) {
                        errorBOM = response_parser(data, /errorBom = ([^;]+)/);
                        if(errorBOM?.modelObject?.step == "Error"){ errorMessage = errorBOM.modelObject?.messages[0]?.subText || errorMessage; }
                        batchError("<strong>Error:</strong> " + errorMessage + " (<a href='"+login_url+"'>Login</a>) ");
                        resetSearch(); return false;
                    }
                    tab_id = requestVars.TAB_ID ? requestVars.TAB_ID : "";
                    batchError(false);
                    form_submit_url = availability_url + tab_id;
                    if(callback) callback();
                } else if (response.readyState == 4) {
                    errorBOM = response_parser(response.responseText, /errorBom = ([^;]+)/);
                    if(errorBOM?.modelObject?.step == "Error"){ errorMessage = errorBOM.modelObject?.messages[0]?.subText || errorMessage; }
                    resetSearch(); batchError("<strong>Error:</strong> " + errorMessage + " ( <a href='"+login_url+"'>Login</a> ) ");
                }
            }
        }, true);
    }

    function regularSearch(route = [{from: "TPE", to: "TYO", date: dateAdd(14)}], passengers = {adult:1,child:0}, cabinclass ="Y", is_cont_query = false, is_cont_batch = false, flexible = "false"){
        var target;
        if (route.length == 1) { target = newQueryPayload(route[0], passengers, cabinclass, false, flexible); }
        else if (route.length > 1) { target = newMultiPayload(route, passengers, cabinclass); }
        else { return; }
        btn_search.innerHTML = lang.searching;
        btn_search.classList.add("searching");
        if (is_cont_query) value_set("cont_query","1");
        if (is_cont_batch) value_set("cont_batch","1");
        value_set("cont_ts",Date.now());
        if (window.location.href.indexOf("redeem-flight-awards.html") > -1) {
            location.href = target.href;
        } else {
            value_set("redirect_search", target.href);
            location.href = `https://www.cathaypacific.com/cx/${lang.el}_${lang.ec}/book-a-trip/redeem-flights/redeem-flight-awards.html`;
        }
    }

    var bulk_date = "";
    function bulk_search(single_date = false) {
        var no_continue = false;
        if(remaining_days-- == 0){ stop_batch(); no_continue = true; }
        uef_from = input_from.value; uef_to = input_to.value; uef_date = normaliseDate(input_date.value); uef_adult = input_adult.value; uef_child = input_child.value;

        if(!cont_query && window.location.href.indexOf("air/booking/availability") > -1 ){
                const boxes = document.querySelectorAll("body > div");
                boxes.forEach( box => { box.remove() });
                addCss(`html, body {overflow-x:inherit !important;} header {overflow-x:hidden;}`, document.body);
                document.body.append(shadowWrapper);
                shadowContainer.classList.add("results_container");
                document.body.classList.add("cont_query");
        } else if (!cont_query) {
            regularSearch([{from:uef_from.substring(0,3), to:uef_to.substring(0,3), date:uef_date}], {adult:uef_adult, child:uef_child}, "Y", true, true, false, false);
            return;
        }

        bulk_date = bulk_date ? bulk_date : normaliseDate(input_date.value);
        if(route_changed) { div_table_body.innerHTML = ""; bulk_date = normaliseDate(input_date.value); div_ue_container.scrollIntoView({behavior: "smooth", block: "start"}); route_changed = false; }
        var routes = [];
        var rt_from = uef_from.split(",");
        var rt_to = uef_to.split(",");
        var query_count = (rt_from.length * rt_to.length);

        if (!no_continue & remaining_days > Math.ceil(25/query_count)) { remaining_days = (Math.ceil(25/query_count) - 1); }

        // Search each origin/destination combination entered by the user.
        rt_from.forEach(from => {
            rt_to.forEach(to => { routes.push({ from:from, to:to }) });
        });

        var this_route = routes.shift();
        var populate_next_route = function(flights){
            insertResults(this_route.from, this_route.to, bulk_date, flights);
            if (routes.length <= 0) {
                bulk_date = dateAdd(1,bulk_date);
                if (single_date) stop_batch();
                bulk_search();
            } else {
                this_route = routes.shift();
                searchAvailability(this_route.from, this_route.to, bulk_date, uef_adult, uef_child, populate_next_route);
            }
        }
        searchAvailability(this_route.from, this_route.to, bulk_date, uef_adult, uef_child, populate_next_route);
    }

    function searchAvailability(from, to, date, adult, child, callback) {
        if(stop_search){ stop_search = false; searching = false; return; }
        searching = true;
        if(!/^[A-Z]{3}$/.test(to)){ callback({ modelObject :{ isContainingErrors : true, messages: [{ text: lang.invalid_code }] }}); return; }

        var requests = { ...requestVars };
        requests.B_DATE_1 = date + "0000";
        requests.B_LOCATION_1 = from;
        requests.E_LOCATION_1 = to;
        delete requests.ENCT; delete requests.SERVICE_ID; delete requests.DIRECT_LOGIN; delete requests.ENC;

        var params = "";
        for ( var key in requests ) { params = params + key + "="+ requests[key] + "&"; }

        httpRequest({
            method: "POST", url: form_submit_url, withCredentials: "true",
            headers: { "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json, text/plain, */*" }, data: params,
            onreadystatechange: function(response) {
                var search_again = function(){ searchAvailability(from, to, date, adult, child, callback); }
                if(response.readyState == 4 && response.status == 200) {
                    batchError(false);
                    try { var data = JSON.parse(response.responseText); } catch { batchError("Response not valid JSON."); return; }
                    if(data.modelObject) { callback(data); }
                    else if(data.pageBom) { callback(JSON.parse(data.pageBom)); }
                    else { batchError("modelObject does not exist."); }
                } else if(response.readyState == 4 && response.status == 404) { batchError(lang.key_exhausted); newTabID(search_again); }
                else if(response.readyState == 4 && response.status >= 300) { batchError(lang.getting_key); newTabID(search_again); }
            }
        }, true);
    }

    function insertResults(from, to, date, pageBom){
        if(!shadowRoot.querySelector('.bulk_table tr[data-date="' + date + '"]')) {
            var results_row = `<tr data-date='${date}'><td class='bulk_date'><a href='javascript:void(0);' data-book='true' data-date='${date}'>${toDashedDate(date)}</a>${dateWeekday(date)}</td><td class='bulk_flights'></td></tr>`;
            shadowRoot.querySelector(".bulk_table tbody").insertAdjacentHTML("beforeend", results_row);
        }

        var noflights = true;
        var flightHTML = `<div data-from="${from}" data-to="${to}"><span class="flight_title">${from} - ${to}<a href="javascript:void(0)" class="bulk_go_book" data-book="true" data-date="${date}" data-from="${from}" data-dest="${to}">Book &raquo;</a></span><div class="flight_list">`;

        if(pageBom.modelObject?.isContainingErrors) {
            flightHTML += `<span class='bulk_response_error'><strong>Error:</strong> ${pageBom.modelObject?.messages[0]?.text}</span>`;
        } else {
            var flights = pageBom.modelObject?.availabilities?.upsell?.bounds[0].flights;
            flights.forEach((flight) => {
                var available = "";
                var f1 = +flight.segments[0].cabins?.F?.status || 0;
                var j1 = +flight.segments[0].cabins?.B?.status || 0;
                var p1 = +flight.segments[0].cabins?.N?.status || 0;
                var y1 = (+flight.segments[0].cabins?.E?.status || 0) + (+flight.segments[0].cabins?.R?.status || 0);
                var d_f = false, d_j = false, d_p = false, d_y = false;
                var n_f = 0, n_j = 0, n_p = 0, n_y = 0;
                var leg1_airline = flight.segments[0].flightIdentifier.marketingAirline;
                var leg1_flight_no = flight.segments[0].flightIdentifier.flightNumber;
                var leg1_dep_time = getFlightTime(flight.segments[0].flightIdentifier.originDate);
                var leg1_arr_time = getFlightTime(flight.segments[0].destinationDate);
                var leg1_duration = getFlightTime(flight.duration,true);
                var leg1_origin = flight.segments[0].originLocation;
                var leg1_dest = flight.segments[0].destinationLocation;
                var flightkey;

                if(flight.segments.length == 1) {
                    if (f1 >= 1) { available += ` <span class='bulk_cabin bulk_f'>F <b>${f1}</b></span>`; d_f = true; }
                    if (j1 >= 1) { available += ` <span class='bulk_cabin bulk_j'>J <b>${j1}</b></span>`; d_j = true; }
                    if (p1 >= 1) { available += ` <span class='bulk_cabin bulk_p'>PY <b>${p1}</b></span>`; d_p = true; }
                    if (y1 >= 1) { available += ` <span class='bulk_cabin bulk_y'>Y <b>${y1}</b></span>`; d_y = true; }
                    flightkey = date+leg1_origin.slice(-3)+leg1_dest.slice(-3)+"_"+leg1_airline+leg1_flight_no;
                    if (available != "") {
                        const pointsText = estimateCxPoints(flight.segments, { f: d_f, j: d_j, p: d_p, y: d_y });
                        flightHTML += `<div class="flight_wrapper"><div class='flight_item direct' data-flightinfo='${flightkey}' data-flightavail='${f1 + "_" + j1+ "_" + p1+ "_" + y1}' data-direct='1' data-f='${(d_f ? 1 : 0)}' data-j='${(d_j ? 1 : 0)}' data-p='${(d_p ? 1 : 0)}' data-y='${(d_y ? 1 : 0)}'><img src='https://book.cathaypacific.com${static_path}common/skin/img/airlines/logo-${leg1_airline.toLowerCase()}.png'><span class="flight_num">${leg1_airline+leg1_flight_no}</span>${available}<span class="flight_points">${pointsText}</span><span class="chevron"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6.34317 7.75732L4.92896 9.17154L12 16.2426L19.0711 9.17157L17.6569 7.75735L12 13.4142L6.34317 7.75732Z" fill="currentColor"></path></svg></span></div><div class="flight_info"><span class="info_flight">${leg1_airline+leg1_flight_no} (${leg1_origin.slice(-3)} ✈ ${leg1_dest.slice(-3)})</span><span class="info_dept"><span>Departs:</span> ${leg1_dep_time}</span><span class="info_arr"><span>Arrives:</span> ${leg1_arr_time}</span><span class="info_duration"><span>Total Flight Duration:</span> ${leg1_duration}</span><span class="info_points">${pointsText}</span></div>`;
                        noflights = false; flightHTML += `</div>`;
                    }
                } else {
                    var f2 = +flight.segments[1].cabins?.F?.status || 0;
                    var j2 = +flight.segments[1].cabins?.B?.status || 0;
                    var p2 = +flight.segments[1].cabins?.N?.status || 0;
                    var y2 = (+flight.segments[1].cabins?.E?.status || 0) + (+flight.segments[1].cabins?.R?.status || 0);
                    if (f1 >= 1 && f2 >= 1) { d_f = true; n_f = Math.min(f1, f2); available += ` <span class='bulk_cabin bulk_f'>F <b>${ n_f }</b></span>`; }
                    if (j1 >= 1 && j2 >= 1) { d_j = true; n_j = Math.min(j1, j2); available += ` <span class='bulk_cabin bulk_j'>J <b>${ n_j }</b></span>`; }
                    if (p1 >= 1 && p2 >= 1) { d_p = true; n_p = Math.min(p1, p2); available += ` <span class='bulk_cabin bulk_p'>PY <b>${ n_p }</b></span>`; }
                    if (y1 >= 1 && y2 >= 1) { d_y = true; n_y = Math.min(y1, y2); available += ` <span class='bulk_cabin bulk_y'>Y <b>${ n_y }</b></span>`; }
                    var leg2_airline = flight.segments[1].flightIdentifier.marketingAirline;
                    var leg2_flight_no = flight.segments[1].flightIdentifier.flightNumber;
                    var leg2_dep_time = getFlightTime(flight.segments[1].flightIdentifier.originDate);
                    var leg2_arr_time = getFlightTime(flight.segments[1].destinationDate);
                    var leg2_origin = flight.segments[1].originLocation;
                    var leg2_dest = flight.segments[1].destinationLocation;
                    var transit_time = getFlightTime(flight.segments[1].flightIdentifier.originDate - flight.segments[0].destinationDate,true);
                    var stopcity = /^[A-Z]{3}:([A-Z:]{3,7}):[A-Z]{3}_/g.exec(flight.flightIdString)[1].replace(":"," / ");
                    flightkey = date+leg1_origin.slice(-3)+leg2_dest.slice(-3)+"_"+leg1_airline+leg1_flight_no+"_"+stopcity+"_"+leg2_airline+leg2_flight_no;
                    if (available != "") {
                        const pointsText = estimateCxPoints(flight.segments, { f: d_f, j: d_j, p: d_p, y: d_y });
                        flightHTML += `<div class="flight_wrapper"><div class='flight_item' data-direct='0' data-flightinfo='${flightkey}'  data-flightavail='${n_f + "_" + n_j + "_" + n_p + "_" + n_y}' data-f='${ d_f ? 1 : 0 }' data-j='${ d_j ? 1 : 0 }' data-p='${ d_p ? 1 : 0 }' data-y='${ d_y ? 1 : 0 }'><img src='https://book.cathaypacific.com${static_path}common/skin/img/airlines/logo-${leg1_airline.toLowerCase()}.png'><span class="flight_num">${leg1_airline + leg1_flight_no}<span class='stopover'>${stopcity}</span>${leg2_airline + leg2_flight_no}</span>${available}<span class="flight_points">${pointsText}</span><span class="chevron"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6.34317 7.75732L4.92896 9.17154L12 16.2426L19.0711 9.17157L17.6569 7.75735L12 13.4142L6.34317 7.75732Z" fill="currentColor"></path></svg></span></div><div class="flight_info"><span class="info_flight">${leg1_airline+leg1_flight_no} (${leg1_origin.slice(-3)} ✈ ${leg1_dest.slice(-3)})</span><span class="info_dept"><span>Departs:</span> ${leg1_dep_time}</span><span class="info_arr"><span>Arrives:</span> ${leg1_arr_time}</span><span class="info_transit"><span>Transit Time:</span> ${transit_time}</span><span class="info_flight">${leg2_airline+leg2_flight_no} (${leg2_origin.slice(-3)} ✈ ${leg2_dest.slice(-3)})</span><span class="info_dept"><span>Departs:</span> ${leg2_dep_time}</span><span class="info_arr"><span>Arrives:</span> ${leg2_arr_time}</span><span class="info_duration"><span>Total Flight Duration:</span> ${leg1_duration}</span><span class="info_points">${pointsText}</span></div>`;
                        noflights = false; flightHTML += `</div>`;
                    }
                }
            });
        }
        flightHTML += "</div></div>"
        shadowRoot.querySelector('.bulk_table tr[data-date="' + date + '"] .bulk_flights').insertAdjacentHTML("beforeend", flightHTML);
        stickyFooter();
        if(autoScroll) shadowRoot.querySelector(".bulk_results").scrollIntoView({ behavior: "smooth", block: "end", inline: "nearest" });
    }

    window.addEventListener('wheel', function(){ autoScroll = (window.innerHeight + window.scrollY) >= document.body.scrollHeight; });
    window.addEventListener('touchmove', function(){ autoScroll = (window.innerHeight + window.scrollY) >= document.body.scrollHeight; });

    unsafeWindow.searchAwards = function(e){
        let origin = e.target.closest("tr").querySelector(".rt-origin span");
        let dest = e.target.closest("tr").querySelector(".rt-dest span");
        if(!data.routes[[origin.innerText,dest.innerText].sort().join("-")]?.length) { alert("Invalid route."); return; }
        let target = newQueryPayload({from:origin.innerText, to:dest.innerText, date:dateAdd(14)}, {adult:1, child:0}, "Y", true, false);
        value_set("uef_from",origin.innerText); value_set("uef_to",dest.innerText); value_set("cont_ts",Date.now()); value_set("cont_query","1"); value_set("cont_batch","0"); value_set("redirect_search",target.href); value_set("cxplanner_flights",fullRoute);
        window.open(`https://www.cathaypacific.com/cx/${lang.el}_${lang.ec}/book-a-trip/redeem-flights/redeem-flight-awards.html`, "cxplanner", "noopener noreferrer");
    };

    function stickyFooter() {
        var bulkboxOffset = div_bulk_box.getBoundingClientRect();
        if(bulkboxOffset.bottom < window.innerHeight) { div_footer.classList.remove("bulk_sticky"); shadowRoot.querySelector(".bulk_results").style.paddingBottom = "0px" }
        else { div_footer.classList.add("bulk_sticky"); shadowRoot.querySelector(".bulk_results").style.paddingBottom = "65px" }
    }

//============================================================
// Initialise
//============================================================

    function initSearchBox() {
        initCXvars();
        shadowContainer.appendChild(searchBox);
        assignElemets();

        elevate();

        addFormListeners();
        window.onscroll = function() { stickyFooter() };
        autocomplete(input_from, "origins");
        autocomplete(input_to, "origins");
        getOrigins();
        if (cont_query) {
            reset_cont_vars();
            if (Date.now() - cont_ts > 60*5*1000 && !debug) return;
            btn_batch.innerHTML = lang.searching_w_cancel;
            btn_batch.classList.add("bulk_searching");
            document.body.classList.add("cont_query");
            setTimeout(() => { bulk_click(cont_batch ? false : true); }, "1000")
        }
    };

    function initCXplannerBox(){
        if(cxplanner_flights){
            const cxplanner_box = document.createElement("div");
            let html = "";
            cxplanner_flights.forEach(item=>{ if(item) html += `<a href="#" class="planner_route" data-route="${item}">${item}</a>`; })
            cxplanner_box.innerHTML = "<div id='planner_routes'>"+html+"</div>";
            shadowContainer.appendChild(cxplanner_box);
            value_set("cxplanner_flights", [])
            cxplanner_box.addEventListener("click",function(e){
                if(e.target.dataset["route"]){ route_changed = true; input_from.value = e.target.dataset["route"].split("-")[0]; input_to.value = e.target.dataset["route"].split("-")[1]; }
            })
        }
    }

    if(window.location.href.indexOf("cathaypacific") > -1){ initRoot(); }
})();
